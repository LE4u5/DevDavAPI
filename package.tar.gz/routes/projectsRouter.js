const express = require('express');
const mongoose = require('mongoose');
const Project = require('../data/models/projects');


mongoose.connect('mongodb://192.168.1.145:27017/DevApi', {useNewUrlParser: true, useUnifiedTopology: true});

const projectsRouter = express.Router();

projectsRouter.route('/list')
.get( async (req, res) => {
    try{
    const pj = await Project.find({});
    console.log(pj);
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(pj));
    }
    catch(err){
        console.log('Failed Request.')
    }
})

module.exports = projectsRouter;